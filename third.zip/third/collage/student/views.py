from django.http import HttpResponse
from django.shortcuts import render, redirect


def index(request):
    return render(request,'index.html')

def about(request):   
    return render(request,'about.html')

def appointment(request):   
    return render(request,'appointment.html')

# def call-to-action(request):   
#     return render(request,'call-to-action.html')


def classes(request):   
    return render(request,'classes.html')


def contact(request):   
    return render(request,'contact.html')


def facility(request):   
    return render(request,'facility.html')


def team(request):   
    return render(request,'team.html')


def testimonial(request):   
    return render(request,'testimonial.html')


# def appointment(request):   
#     return render(request,'appointment.html')


