from django.shortcuts import render,HttpResponse




# Create your views here.


def index(request):
    context = {
        "vsriable":"this is sent"
    }
    return render(request, 'index.html', context)
    # return HttpResponse("this is home page")

def about(request):
    return render(request, 'about.html')
    # return HttpResponse("this is about page")


def doctors(request):
    return render(request, 'doctors.html')

def service(request):
    return render(request, 'service.html')
    # return HttpResponse("this is service page")

def appointment(request):
    return render(request, 'appointment.html')

def testimonial(request):
    return render(request, 'testimonial.html')

def contact(request):
    return render(request, 'contact.html')
    # return HttpResponse("this is contact page")