from django.contrib import admin
from django.urls import path
from patient import views

urlpatterns = [
    
    path("", views.index, name='patient'),
    path("about", views.about, name='about'),
    path("service", views.service, name='service'),
    path("appointment", views.appointment, name='appointment'),
    path('testimonial', views.testimonial, name='testimonial'),
    path("doctors", views.doctors, name='doctors'),
    path("contact", views.contact, name='contact'),
]    
